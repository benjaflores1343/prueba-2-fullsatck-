package com.eventura.serviciotareas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioTareasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioTareasApplication.class, args);
	}

}
