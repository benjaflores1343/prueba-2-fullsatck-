package com.eventura.serviciotareas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioTareasApplicationTests {

	@Test
	void contextLoads() {
	}

}
