package com.eventura.tareas_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TareasServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
