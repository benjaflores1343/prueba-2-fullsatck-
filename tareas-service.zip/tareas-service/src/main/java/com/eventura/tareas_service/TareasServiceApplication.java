package com.eventura.tareas_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TareasServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TareasServiceApplication.class, args);
	}

}
